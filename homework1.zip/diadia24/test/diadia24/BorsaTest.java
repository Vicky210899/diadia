package diadia24;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import diadia.attrezzi.Attrezzo;
import diadia.giocatori.Borsa;

public class BorsaTest {
	
	Borsa b = new Borsa();
	Attrezzo spada;
	Attrezzo pugnale;
	
	@Before 
	public void setUp() {
		pugnale = new Attrezzo("pugnale", 3);
		spada = new Attrezzo ("spada", 16);
	}
	
	@Test
	public void testAddAttrezzoPesoMinoreDiDieci() {
		assertTrue(b.addAttrezzo(pugnale));
	}
	
	@Test
	public void testAddAttrezzoPesoMaggioreDiDieci() {
		assertFalse(b.addAttrezzo(spada));

	}
	
	@Test
	public void testGetPeso() {
		b.addAttrezzo(pugnale);
		assertEquals(pugnale, b.getAttrezzo("pugnale"));
	}

}
