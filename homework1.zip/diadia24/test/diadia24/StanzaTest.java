package diadia24;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import diadia.ambienti.Stanza;
import diadia.attrezzi.Attrezzo;

public class StanzaTest {
	
	private Stanza n1;
	private Stanza n2;
	private Stanza n3;
	private Stanza nord_n1;
	private Stanza sud_n1;
	private Stanza est_n2;
	private Stanza ovest_n3;
	
	private Attrezzo bastone;
	private Attrezzo fucile;
	private Attrezzo ascia;
	
	@Before 
	public void SetUp() {
		this.n1 = new Stanza("N1");
		this.n2 = new Stanza("N2");
		this.n3 = new Stanza("N3");
		
		this.nord_n1 = new Stanza ("a nord di n1");
		this.sud_n1 = new Stanza ("a sud di n1");
		this.est_n2 = new Stanza ("a est di n2");
		this.ovest_n3 = new Stanza ("a ovest di n3");
		
		this.bastone = new Attrezzo ("Bastone", 1);
		this.fucile = new Attrezzo ("Fucile", 5);
		this.ascia = new Attrezzo("Ascia", 10);
		
		this.n1.addAttrezzo(bastone);
		this.n2.addAttrezzo(ascia);
		this.n3.addAttrezzo(fucile);
		
		this.n1.impostaStanzaAdiacente("nord", nord_n1);
		this.n1.impostaStanzaAdiacente("sud", sud_n1);
		this.n2.impostaStanzaAdiacente("est", est_n2);
		this.n3.impostaStanzaAdiacente("ovest", ovest_n3);
		
		
		
	}
	
	/**
	 * Test per vedere le stanze adiacenti  
	 * utilizzando il metodo getStanzaAdiacentre()
	 * lo faccio per tutte le stanze che ho creato */

	@Test
	public void testStanzaNordiDiN1() {
		assertEquals(nord_n1, n1.getStanzaAdiacente("nord"));
	}
	
	@Test
	public void testStanzaSudDiN1() {
		assertEquals(sud_n1, n1.getStanzaAdiacente("sud"));
	}
	
	@Test
	public void testStanzaEstDiN2() {
		assertEquals(est_n2, n2.getStanzaAdiacente("est"));
	}
	
	@Test
	public void testStanzaOvestDiN3() {
		assertEquals(ovest_n3, n3.getStanzaAdiacente("ovest"));
	}
	
	
	/**
	 * test per metodo getNome()
	 * 
	 * */
	
	@Test
	public void testGetNomeN1() {
		assertEquals("N1", n1.getNome());
	}
	
	@Test
	public void testGetNomeN2Est() {
		assertEquals("a est di n2", est_n2.getNome());
	}
	
	@Test
	public void testGetNomeN3Ovest() {
		assertEquals("a ovest di n3", ovest_n3.getNome());
	}
	
	
	/**
	 * test per verificare che esiiste attrezzo nella stanza che passiamo
	 * come parametro 
	 * 
	 * utilizzando il metodo 
	 * hasAttrezzo() 
	 * */
	
	@Test 
	public void testN1_possiede_Bastone() {
		assertTrue(this.n1.hasAttrezzo("Bastone"));
	}
	
	
	@Test 
	public void testN2_NonPossiede_Fucile() {
		assertFalse(this.n2.hasAttrezzo("Fucile"));
	}
	
	@Test 
	public void testN3_possiede_Fucile() {
		assertTrue(this.n3.hasAttrezzo("Fucile"));
	}
	
	
	/*
	 * test getNome() su attrezzo in stanza
	 * */
	
	@Test
	public void testGetNomeBastone() {
		assertEquals("Bastone", this.n1.getAttrezzo("Bastone").getNome());
	}

	@Test
	public void testGetNomeAscia() {
		assertEquals("Ascia", this.n2.getAttrezzo("Ascia").getNome());
	}

	@Test
	public void testGetNomeFucile() {
		assertEquals("Fucile", this.n3.getAttrezzo("Fucile").getNome());
	}

}
