package diadia24;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

import diadia.Partita;
import diadia.ambienti.Stanza;

public class PartitaTest {

	Partita p = new Partita();
	
	Stanza s = new Stanza("Stanza");
	
	@Test 
	public void testGetStanzaVincente() {
		assertEquals("Biblioteca" , p.getLabirinto().getStanzaVincente().getNome());
	}
	
	@Test 
	public void testSetStanzaCorrente() {
		p.getLabirinto().setStanzaCorrente(s);
		assertEquals(s, p.getLabirinto().getStanzaCorrente());
	}
	
	@Test
	public void testIsFinita() {
		assertFalse(p.isFinita());
	}
	

}
